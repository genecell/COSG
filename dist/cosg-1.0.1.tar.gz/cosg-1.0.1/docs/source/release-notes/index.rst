Release notes
=============

Version 1.0
-----------

.. include:: 1.0.0.rst

