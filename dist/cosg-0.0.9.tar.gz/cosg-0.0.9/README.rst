COSG – Marker Gene Identification in Single Cell Sequencing Data
=======================================================================================================

Overview
---------
COSG efficiently identifies marker genes for one million cells in less than two minutes. 

The method and benchmarking results are described in `Dai et al., (2021)`_.

Installation
-------------
Runnig this package requires a Python environment (>=3.6).

Usage
---------
Open a Python session and type in:
::
    import cosg


Tutorials
---------

COSG provides several tutorials for different purposes:

- The `Introduction <https://cosg.readthedocs.io/en/latest/introduction.html>`_ tutorial provides a quick-start guide for using COSG.

- The `Run on simulated data <https://cosg.readthedocs.io/en/latest/run_on_simulated_data.html>`_ tutorial provides a guide for benchmarking COSG and other methods on simulated data.

Question
---------
For questions about the code and tutorial, please contact Min Dai, daimin@zju.edu.cn.


Citation
---------
If COSG is useful for your research, please consider citing `Dai et al., (2021)`_.

.. _Dai et al., (2021): https://link

