.. COSG documentation master file, created by
   sphinx-quickstart on Sat Nov 28 22:04:53 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: ../../README.rst

.. toctree::
   :maxdepth: 1
   :hidden:
   
   usage
   installation
   api/index
   release-notes/index
