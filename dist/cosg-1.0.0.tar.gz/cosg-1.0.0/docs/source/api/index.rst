

API
===


Import cosg as::

   import cosg as cosg


Marker gene identification
------------------------------
.. module:: cosg
.. currentmodule:: cosg


.. autosummary::
   :toctree: .
   
   cosg