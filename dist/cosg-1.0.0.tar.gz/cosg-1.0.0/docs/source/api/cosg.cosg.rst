﻿cosg.cosg
=========

.. currentmodule:: cosg

.. autofunction:: cosg