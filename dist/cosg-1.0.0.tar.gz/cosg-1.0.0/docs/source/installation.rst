Installation
------------

Runnig this package requires a Python environment (>=3.6).


Development Version
~~~~~~~~~~~~~~~~~~~
To use the latest version `on GitHub <https://github.com/genecell/COSG>`_: please clone the repository and `cd` into the root directory, and run:
::
    pip install -e .

PyPI
~~~~
Please run:
::
    pip install 'COSG'